# SSD1306
<!-- START COMPATIBILITY TABLE -->

## Compatibility

MCU                | Tested Works | Doesn't Work | Not Tested  | Notes
------------------ | :----------: | :----------: | :---------: | -----
HelTec Wifi Lora 32|20180712|||100KHz unless additional 3.3k pullups, max 430KHz, 
<!-- END COMPATIBILITY TABLE -->
